The attached MIZ files complement the Contextual menus video which I will be uploading to my you tube channel very shortly
Video - https://www.youtube.com/watch?v=v8gexx2Z17s


The xls is needed to create customised Contexual menus of your own.

Please feel free to vie my other videos here
Pukin Dog You Tube Channel https://www.youtube.com/channel/UCbRuGy5Hr4QbNNij8OMWDNw
